# Third-party material

The root MIT license covers original project material only.

- **Wurth Elektronik WE-PD-1050P STEP model:** the original, unmodified manufacturer file is included in `pcb/models/L_Wurth_WE-PD-1050P.step`. Its header states CC BY-SA 4.0 with an exception for electronic designs and generated files. The original manufacturer disclaimer is retained in `pcb/models/WURTH-LICENSE.txt`; the source URL, library part mapping and SHA-256 are in `pcb/models/model-provenance.json`. This model is not relicensed under MIT.
- **KiCad libraries:** schematic symbols, standard footprint geometry and installed component models originate from KiCad libraries and retain the applicable library licenses and design-output exceptions. Standard external 3D assets are resolved from the user's KiCad installation, not redistributed wholesale in this package.
- **Texas Instruments SPICE model:** the official model is fetched separately through the included source/hash script. It is not included as original project code and is not relicensed. TI's model notices and terms continue to apply.
- **Manufacturer documentation:** official documents are linked in the reference index and BOM. Manufacturer performance curves are not represented as this project's simulation or hardware measurements.

All project visuals are native CAD exports, data plots, calculations, or an original technical diagram of the actual circuit. No generative-image model or stock hardware photograph was used.
