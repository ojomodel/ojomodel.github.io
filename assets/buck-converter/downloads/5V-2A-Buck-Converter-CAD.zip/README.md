# 5 V / 2 A Buck Converter — CAD Files

**Designed and Simulated — Not Hardware Tested.**

This CAD-only subset contains the editable schematic and 54 × 34 mm, two-layer
PCB for a TI TPS54302 design targeting 9–18 V input and 5 V / 2 A output.
The targets are design goals, not demonstrated physical performance.

Open `schematic/circuit-design.kicad_pro` for the schematic and
`pcb/buck-converter.kicad_pro` for the board. Keep the folder structure intact.
The source files were created and checked with **KiCad 10.0.6**. Use KiCad 10
with its standard symbol, footprint and 3D model libraries installed. Standard
3D models resolve through `${KICAD10_3DMODEL_DIR}`. The project-local
`Buck_Project.pretty` footprint library and both `fp-lib-table` files are
included. The unmodified Würth WE-PD-1050P STEP model resolves from
`pcb/models/`; its origin, original license and manufacturer disclaimer are
included there. Standard KiCad 3D libraries are dependencies, not bundled here.

`schematic/erc-report.json` and `pcb/drc-report.json` are unchanged native KiCad
check outputs. They report zero ERC violations, zero DRC violations and zero
unconnected items under their recorded settings. The reports also retain their
ignored-check lists. Passing these configured checks does not establish circuit
performance, manufacturability, loop stability or physical safety.

The completed simulations in the separate original project used an explicitly
educational assumed controller. The official TI PSpice model failed transient
convergence, so those simulations do not validate TPS54302 transient behavior.
No physical board has been fabricated or tested; continuous 2 A thermal
operation, physical efficiency, full-temperature accuracy, loop stability and
hardware performance remain unverified. A manufacturer STEP model may simplify
proprietary component details; it is CAD geometry, not a photograph.

This download deliberately contains no graphs, diagrams rendered as images,
summary graphics, simulation results, technical reports, portfolio pages or
3D render images. It is not the original complete project ZIP. The BOM and
native CAD/check data are included for design review. All original engineering
files and license notices are byte-for-byte unchanged; only this subset README
was added. `THIRD-PARTY-NOTICES.md` is the original source-project notice and
may refer to material that is not distributed in this CAD-only subset.
